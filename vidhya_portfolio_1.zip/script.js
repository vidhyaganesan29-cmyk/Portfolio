// ============================================================
// PARTICLE SYSTEM
// ============================================================
const canvas = document.getElementById('particles-canvas');
const ctx = canvas.getContext('2d');

let W, H;
let particles = [];
let mouse = { x: -9999, y: -9999 };

const PARTICLE_COUNT = 110;
const CONNECT_DIST = 130;
const MOUSE_DIST = 100;

function resize() {
  W = canvas.width = window.innerWidth;
  H = canvas.height = window.innerHeight;
}
resize();
window.addEventListener('resize', resize);

document.addEventListener('mousemove', e => {
  mouse.x = e.clientX;
  mouse.y = e.clientY;
});
document.addEventListener('mouseleave', () => {
  mouse.x = -9999;
  mouse.y = -9999;
});

class Particle {
  constructor() {
    this.reset(true);
  }

  reset(init) {
    this.x = Math.random() * W;
    this.y = init ? Math.random() * H : H + 10;
    this.size = Math.random() * 1.8 + 0.5;
    this.speedX = (Math.random() - 0.5) * 0.4;
    this.speedY = -(Math.random() * 0.5 + 0.15);
    this.opacity = Math.random() * 0.5 + 0.1;
    this.baseOpacity = this.opacity;
    const r = Math.random();
    if (r < 0.33) {
      this.color = '124,111,255'; // purple
    } else if (r < 0.66) {
      this.color = '255,111,168'; // pink
    } else {
      this.color = '111,255,212'; // teal
    }
  }

  update() {
    this.x += this.speedX;
    this.y += this.speedY;

    const dx = this.x - mouse.x;
    const dy = this.y - mouse.y;
    const dist = Math.sqrt(dx * dx + dy * dy);

    if (dist < MOUSE_DIST) {
      const force = (MOUSE_DIST - dist) / MOUSE_DIST;
      this.x += (dx / dist) * force * 1.5;
      this.y += (dy / dist) * force * 1.5;
      this.opacity = Math.min(1, this.baseOpacity + force * 0.5);
    } else {
      this.opacity += (this.baseOpacity - this.opacity) * 0.05;
    }

    if (this.y < -10 || this.x < -10 || this.x > W + 10) {
      this.reset(false);
    }
  }

  draw() {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(${this.color},${this.opacity})`;
    ctx.fill();
  }
}

for (let i = 0; i < PARTICLE_COUNT; i++) {
  particles.push(new Particle());
}

function animate() {
  ctx.clearRect(0, 0, W, H);

  for (let i = 0; i < particles.length; i++) {
    particles[i].update();
    particles[i].draw();

    for (let j = i + 1; j < particles.length; j++) {
      const dx = particles[i].x - particles[j].x;
      const dy = particles[i].y - particles[j].y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist < CONNECT_DIST) {
        const alpha = (1 - dist / CONNECT_DIST) * 0.18;
        ctx.beginPath();
        ctx.moveTo(particles[i].x, particles[i].y);
        ctx.lineTo(particles[j].x, particles[j].y);
        ctx.strokeStyle = `rgba(124,111,255,${alpha})`;
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }
    }
  }

  requestAnimationFrame(animate);
}

animate();

// ============================================================
// SCROLL FADE-IN ANIMATION
// ============================================================
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));
